<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Beneficiarios</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">


                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-beneficiario')): ?>
                                <a class="btn btn-warning" href="<?php echo e(route('beneficiarios.create')); ?>">Nuevo</a>
                            <?php endif; ?>
                            <div class="table-responsive"><br>
                                <table class="table table-striped mt-2" id="dataTable">
                                    <thead style="background-color:#575756">
                                        <th style="display: none;">ID</th>
                                        <th style="color:#fff;">Documento</th>
                                        <th style="color:#fff;">Nombre</th>
                                        <th style="color:#fff;">Apellido</th>
                                        <th style="color:#fff;">Direccion</th>
                                        <th style="color:#fff;">Genero</th>
                                        <th style="color:#fff;">Parentesco</th>
                                        <th style="color:#fff;">Fec. Nacimiento</th>
                                        <th style="color:#fff;">Edad</th>
                                        <th style="color:#fff;">Telefono</th>
                                        <th style="color:#fff;">Funcionario</th>
                                        <th style="color:#fff;">acciones</th>

                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $beneficiarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beneficiario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td style="display: none;"><?php echo e($beneficiario->id); ?></td>
                                                <td><?php echo e($beneficiario->ced_beneficiario); ?></td>
                                                <td><?php echo e($beneficiario->nom_beneficiario); ?></td>
                                                <td><?php echo e($beneficiario->ape_beneficiario); ?></td>
                                                <td><?php echo e($beneficiario->dir_beneficiario); ?></td>
                                                <td><?php echo e($beneficiario->gen_beneficiario); ?></td>
                                                <td><?php echo e($beneficiario->id_parentesco); ?></td>
                                                <td><?php echo e($beneficiario->fec_nac_beneficiario); ?></td>
                                                <td><?php echo e($beneficiario->edad_beneficiario); ?></td>
                                                <td><?php echo e($beneficiario->tel_beneficiario); ?></td>
                                                <td><?php echo e($beneficiario->nom_funcionario); ?></td>
                                                <td>
                                                    <form
                                                        action="<?php echo e(route('beneficiarios.destroy', $beneficiario->id)); ?>"
                                                        method="POST">
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar-beneficiario')): ?>
                                                            <a class="btn btn-info"
                                                                href="<?php echo e(route('beneficiarios.edit', $beneficiario->id)); ?>">Editar</a>
                                                        <?php endif; ?>

                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('borrar-beneficiario')): ?>
                                                            <button type="submit" class="btn btn-danger">Borrar</button>
                                                        <?php endif; ?>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/imac003/Desktop/MyControlSMA_PHP8/MyControlSMA_git/resources/views/beneficiarios/index.blade.php ENDPATH**/ ?>