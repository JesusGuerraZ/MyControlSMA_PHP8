<?php $__env->startSection('title'); ?>
    MyControlSMA-Crear servicio
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!--Formulario byron porque es timido-->
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Crear orden de servicio</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">

                            <?php if($errors->any()): ?>
                                <div class="alert alert-dark alert-dismissible fade show" role="alert">
                                    <strong>¡Revise los campos!</strong>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="badge badge-danger"><?php echo e($error); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>

                            <form action="<?php echo e(route('oservicios.store')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                
                                <div class="row">
                                    <div class="col-xs-2 col-sm-2 col-md-6">
                                        <div class="form-group">
                                            <label for="fec_reg_oservicio">Fecha registro</label>
                                            <?php $fcha = date('Y-m-d'); ?>
                                            <input type="date" name="fec_reg_oservicio" class="form-control"
                                                value="<?php echo $fcha; ?>">
                                        </div>

                                        <div class="form-group">
                                            <label for="num_oservicio"> Número orden de servicio</label>
                                            <input type="number" name="num_oservicio" class="form-control">
                                        </div>

                                        <div class="form-group">
                                            <label for="">Nombre beneficiario</label>
                                            <select id="country" class="form-control" name="nom_beneficiario">
                                                <option disabled selected>Beneficiarios</option>
                                                <?php $__currentLoopData = $nomBeneficiario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($list->id); ?>">
                                                        <?php echo e($list->nom_beneficiario . ' ' . $list->ape_beneficiario); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <label for="">ID del beneficiario</label>
                                            <select id="state" class="form-control" name="id_beneficiario">
                                            </select>
                                        </div>

                                        <div class="form-group"><br>
                                            <label for="pdf_oservicio">PDF</label><br>
                                            <input type="file" name="pdf_oservicio" class="">
                                        </div>
                                    </div>

                                    <div class="col-xs-2 col-sm-2 col-md-6">
                                        <div class="form-group">
                                            <label for="">Prestador</label>
                                            <?php echo Form::select('ident_prestador', $prestador_nom, [], ['class' => 'form-control']); ?>

                                        </div>
                                        <div class="form-group" style="display: none;">
                                            <label for="">Estado</label>
                                            <select name="est_oservicio" id="est_oservicio" for="est_oservicio"
                                                class="form-control">
                                                <option value="no atendida">No atendida</option>
                                                <option value="atendida">atendida</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <button type="submit" class="btn btn-primary">Guardar</button>
                                        <input type="button" class="btn btn-secondary" value="Cancelar"
                                            onClick="history.go(-1);">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/imac003/Desktop/MyControlSMA_PHP8/MyControlSMA_git/resources/views/oservicios/crear.blade.php ENDPATH**/ ?>