<div class="text-center p-4">
     &copy; <?php echo e(date('Y')); ?> Copyright:
                    <a class="text-reset fw-bold" href="https://gestionredtecnoparquecolombia.com.co/inicio/barranquilla/">Tecnoparque Atlántico - Tecnologías Virtuales</a>
</div>
<?php /**PATH /Users/imac003/Desktop/GITHUB/MyControlSMA_git/resources/views/layouts/footer.blade.php ENDPATH**/ ?>