<?php echo e($slot); ?>

<?php /**PATH /Users/imac003/Desktop/GITHUB/MyControlSMA_git/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>