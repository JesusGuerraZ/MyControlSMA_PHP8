<?php $__env->startSection('title'); ?>
    MyControlSMA-Revision juridica
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Revision juridica</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">


                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-rjuridica')): ?>
                                <a class="btn btn-warning" href="<?php echo e(route('revjuridica.create')); ?>">Nuevo</a>
                            <?php endif; ?>
                            <div class="table-responsive">
                                <table class="table table-striped mt-2">
                                    <thead style="background-color:#575756">
                                        <th style="display: none;">ID</th>
                                        <th style="color:#fff;">PDF Factura</th>
                                        <th style="color:#fff;">PDF Firmas</th>
                                        <th style="color:#fff;">Estado</th>
                                        <th style="color:#fff;">Observaciones</th>
                                        <th style="color:#fff;">Acciones</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $rjuridicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjuridica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td style="display: none;"><?php echo e($rjuridica->id); ?></td>
                                                <td><?php echo e($rjuridica->pdf_fac_rjuridica); ?></td>
                                                <td><?php echo e($rjuridica->pdf_firmas_rjuridica); ?></td>
                                                <td><?php echo e($rjuridica->est_rjuridica); ?></td>
                                                <td><?php echo e($rjuridica->obs_rjuridica); ?></td>
                                                <td>
                                                    <form action="<?php echo e(route('revjuridica.destroy', $rjuridica->id)); ?>"
                                                        method="POST">
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar-rjuridica')): ?>
                                                            <a class="btn btn-info"
                                                                href="<?php echo e(route('revjuridica.edit', $rjuridica->id)); ?>">Editar</a>
                                                        <?php endif; ?>

                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('borrar-rjuridica')): ?>
                                                            <button type="submit" class="btn btn-danger">Borrar</button>
                                                        <?php endif; ?>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- Ubicamos la paginacion a la derecha -->
                            <div class="pagination justify-content-end">
                                <?php echo $rjuridicas->links(); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/imac003/Desktop/GITHUB/MyControlSMA_git/resources/views/revjuridica/index.blade.php ENDPATH**/ ?>