<?php $__env->startSection('title'); ?>
    MyControlSMA-Supervision
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Supervisión</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">


                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-supervisor')): ?>
                                <a class="btn btn-warning" href="<?php echo e(route('supervisor.create')); ?>">Nuevo</a>
                            <?php endif; ?>
                            <div class="table-responsive"><br>
                                <table class="table table-striped mt-2" id="dataTable">
                                    <thead style="background-color:#575756">
                                        <th style="display: none;">ID</th>
                                        <th style="color:#fff;">PDF</th>
                                        <th style="color:#fff;">Estado</th>
                                        <th style="color:#fff;">Firma Servicio</th>
                                        <th style="color:#fff;">Firma Atencion</th>
                                        <th style="color:#fff;">Firma Auditoria</th>
                                        <th style="color:#fff;">Observaciones</th>
                                        <th style="color:#fff;">acciones</th>

                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $supervisores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supervisor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td style="display: none;"><?php echo e($supervisor->id); ?></td>
                                                <td><a href="<?php echo e(asset('/storage/pdf_supervision/' . $supervisor->pdf_fac_supervisor)); ?>"
                                                        target="_blank"><?php echo e($supervisor->pdf_fac_supervisor); ?></a></td>
                                                <td><?php echo e($supervisor->est_supervisor); ?></td>
                                                <td><?php echo e($supervisor->firma_oserv_supervisor); ?></td>
                                                <td><?php echo e($supervisor->firma_oaten_supervisor); ?></td>
                                                <td><?php echo e($supervisor->firma_aud_supervisor); ?></td>
                                                <td><?php echo e($supervisor->obs_supervisor); ?></td>
                                                <td>
                                                    <form action="<?php echo e(route('supervisor.destroy', $supervisor->id)); ?>"
                                                        method="POST">
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar-supervisor')): ?>
                                                            <a class="btn btn-info"
                                                                href="<?php echo e(route('supervisor.edit', $supervisor->id)); ?>">Editar</a>
                                                            <a class="btn btn-secondary" href="">Generar pdf</a>
                                                        <?php endif; ?>

                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('borrar-supervisor')): ?>
                                                            <button type="submit" class="btn btn-danger">Borrar</button>
                                                        <?php endif; ?>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/imac003/Desktop/GITHUB/MyControlSMA_git/resources/views/supervisor/index.blade.php ENDPATH**/ ?>