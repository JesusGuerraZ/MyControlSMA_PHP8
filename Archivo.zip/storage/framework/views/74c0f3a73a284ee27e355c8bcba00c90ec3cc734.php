<?php $__env->startSection('title'); ?>
    MyControlSMA-Editar facturacion
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Editar facturacion</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">

                            <?php if($errors->any()): ?>
                                <div class="alert alert-dark alert-dismissible fade show" role="alert">
                                    <strong>¡Revise los campos!</strong>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="badge badge-danger"><?php echo e($error); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>


                            <form action="<?php echo e(route('facturador.update', $facturador->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12">

                                        <div class="form-group">
                                            <label for="od_oservicio">id_oservicio</label>
                                            <input type="int" name="id_oservicio" class="form-control"
                                                value="<?php echo e($facturador->id_oservicio); ?>">
                                        </div>
                                        <div class="row">
                                            <div class="col-xs-12 col-sm-12 col-md-2">
                                                <div class="form-group">
                                                    <label for="fec_reg_factura">fec_reg_factura</label>
                                                    <input type="date" name="fec_reg_factura" class="form-control"
                                                        value="<?php echo e($facturador->fec_reg_factura); ?>">
                                                </div>

                                                <div class="form-group">
                                                    <label for="fec_factura">fec_factura</label>
                                                    <input type="date" name="fec_factura" class="form-control"
                                                        value="<?php echo e($facturador->fec_factura); ?>">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="valor_factura">valor_factura</label>
                                            <input type="text" name="valor_factura" class="form-control"
                                                value="<?php echo e($facturador->valor_factura); ?>">
                                        </div>

                                        <div class="form-group">
                                            <label for="pdf_facturacion">pdf_facturacion</label><br>
                                            <input type="file" name="pdf_facturacion" class=""
                                                value="<?php echo e($facturador->pdf_facturacion); ?>">
                                        </div>

                                        <div class="form-group">
                                            <label for="aprobada_facturacion">aprobada_facturacion</label><br>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="aprobada_facturacion"
                                                    id="aprobada_facturacion" value="<?php echo e($facturador->aprobada_facturacion); ?>">
                                                <label class="form-check-label" for="aprobada_facturacion">Si</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="aprobada_facturacion"
                                                    id="aprobada_facturacion" value="<?php echo e($facturador->aprobada_facturacion); ?>">
                                                <label class="form-check-label" for="aprobada_facturacion">No</label>
                                            </div>

                                        </div>

                                        <div class="form-group">
                                            <label for="obs_facturacion">obs_facturacion</label>
                                            <input type="text" name="obs_facturacion" class="form-control"
                                                value="<?php echo e($facturador->obs_facturacion); ?>">
                                        </div>
                                        <br>
                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                            <button type="submit" class="btn btn-primary">Guardar</button>
                                            <input type="button" class="btn btn-danger" value="Página anterior"
                                                onClick="history.go(-1);">
                                        </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/imac003/Desktop/GITHUB/MyControlSMA_git/resources/views/facturador/editar.blade.php ENDPATH**/ ?>