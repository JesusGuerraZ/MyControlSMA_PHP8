<?php $__env->startSection('title'); ?>
    MyControlSMA-Validacion
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Validador</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">


                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-validador')): ?>
                                <a class="btn btn-warning" href="<?php echo e(route('validador.create')); ?>">Nuevo</a>
                            <?php endif; ?>
                            <div class="table-responsive"><br>
                                <table class="table table-striped mt-2" id="dataTable">
                                    <thead style="background-color:#575756">
                                        <th style="display: none;">ID</th>
                                        <th style="color:#fff;">PDF Factura</th>
                                        <th style="color:#fff;">PDF Firmas</th>
                                        <th style="color:#fff;">Estado</th>
                                        <th style="color:#fff;">Observaciones</th>
                                        <th style="color:#fff;">Acciones</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $validadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $validador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td style="display: none;"><?php echo e($validador->id); ?></td>
                                                <td><a href="<?php echo e(asset('/storage/pdf_facValidador/'.$validador->pdf_fac_validador)); ?>" target="_blank"><?php echo e($validador->pdf_fac_validador); ?></a></td>
                                                <td><a href="<?php echo e(asset('/storage/pdf_firmas/'.$validador->pdf_firmas_validador)); ?>" target="_blank"><?php echo e($validador->pdf_firmas_validador); ?></a></td>
                                                <td><?php echo e($validador->est_validador); ?></td>
                                                <td><?php echo e($validador->obs_validador); ?></td>
                                                <td>
                                                    <form action="<?php echo e(route('validador.destroy', $validador->id)); ?>"
                                                        method="POST">
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar-validador')): ?>
                                                            <a class="btn btn-info"
                                                                href="<?php echo e(route('validador.edit', $validador->id)); ?>">Editar</a>
                                                        <?php endif; ?>

                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('borrar-validador')): ?>
                                                            <button type="submit" class="btn btn-danger">Borrar</button>
                                                        <?php endif; ?>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- Ubicamos la paginacion a la derecha -->
                            <div class="pagination justify-content-end">
                                <?php echo $validadores->links(); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/imac003/Desktop/GITHUB/MyControlSMA_git/resources/views/validador/index.blade.php ENDPATH**/ ?>