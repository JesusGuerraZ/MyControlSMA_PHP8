<?php $__env->startSection('title'); ?>
    MyControlSMA-Servicio
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Ordenes de servicios</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">


                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-oservicio')): ?>
                                <a class="btn btn-warning" href="<?php echo e(route('oservicios.create')); ?>">Nuevo</a>
                            <?php endif; ?>
                            <div class="table-responsive"><br>
                                <table class="table table-striped mt-2" id="dataTable">
                                    <thead style="background-color:#575756">
                                        <th style="display: none;">ID</th>
                                        <th style="color:#fff;">Fecha de Registro</th>
                                        <th style="color:#fff;">Número</th>
                                        <th style="color:#fff;">Beneficiario</th>
                                        <th style="color:#fff;">Prestador</th>
                                        <th style="display: none;">Fec de Cita</th>
                                        <th style="color:#fff;">PDF</th>
                                        <th style="color:#fff;">Estado</th>
                                        <th style="color:#fff;">Acciones</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oservicios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td style="display: none;"><?php echo e($oservicios->id); ?></td>
                                                <td><?php echo e($oservicios->fec_reg_oservicio); ?></td>
                                                <td><?php echo e($oservicios->num_oservicio); ?></td>
                                                <td><?php echo e($oservicios->id_beneficiario); ?></td>
                                                <td><?php echo e($oservicios->ident_prestador); ?></td>
                                                <td style="display: none;"><?php echo e($oservicios->fec_cita_oservicio); ?></td>
                                                <td><a href="<?php echo e(asset('/storage/pdf_oservicio/' . $oservicios->pdf_oservicio)); ?>"
                                                        target="_blank"><?php echo e($oservicios->pdf_oservicio); ?></a></td>
                                                <td><?php echo e($oservicios->est_oservicio); ?></td>
                                                <td>
                                                    <form action="<?php echo e(route('oservicios.destroy', $oservicios->id)); ?>"
                                                        method="POST">
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar-oservicio')): ?>
                                                            <a class="btn btn-info"
                                                                href="<?php echo e(route('oservicios.edit', $oservicios->id)); ?>">Editar</a>
                                                        <?php endif; ?>

                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('borrar-oservicio')): ?>
                                                            <button type="submit" class="btn btn-danger">Borrar</button>
                                                        <?php endif; ?>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/imac003/Desktop/MyControlSMA_PHP8/MyControlSMA_git/resources/views/oservicios/index.blade.php ENDPATH**/ ?>