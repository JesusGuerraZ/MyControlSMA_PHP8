<?php $__env->startSection('title'); ?>
    MyControlSMA-Editar atencion
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Editar orden de atencion</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">

                        <?php if($errors->any()): ?>
                            <div class="alert alert-dark alert-dismissible fade show" role="alert">
                            <strong>¡Revise los campos!</strong>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge badge-danger"><?php echo e($error); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            </div>
                        <?php endif; ?>


                    <form action="<?php echo e(route('oatencion.update',$oatencion->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-4">
                                        <div class="form-group">
                                            <label for="id_oservicio">Número orden de servicio</label>
                                            <input type="text" name="id_oservicio" class="form-control" value="<?php echo e($oatencion->id_oservicio); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-2 col-sm-2 col-md-2">

                                        <div class="form-group">
                                            <label for="fec_oatencion">Fecha de atención</label>
                                            <input type="date" name="fec_oatencion" class="form-control" value="<?php echo e($oatencion->fec_oatencion); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-2">
                                        <div class="form-group">
                                            <label for="num_oatencion">Núm.Atencion</label>
                                            <input type="text" name="num_oatencion" class="form-control" value="<?php echo e($oatencion->num_oatencion); ?>">

                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-12 col-md-2">
                                        <div class="form-group">
                                             <label for="est_oatencion">Estado</label>
                                            <select type="number" class="form-control" name="est_oatencion"
                                                id="est_oatencion">
                                                <option value="Servicio prestado">Servicio prestado</option>
                                                <option value="Orden anulada">Orden anulada</option>
                                            </select>

                                        </div>
                                    </div>
                                     <div class="col-xs-12 col-sm-12 col-md-10">
                                        <div class="form-group">
                                            <label for="num_oatencion">Observaciones</label>
                                            <input type="text" name="num_oatencion" class="form-control">

                                        </div>
                                            <label for="pdf_oatencion">PDF</label><br>
                                            <input type="file" name="pdf_oatencion" class="" value="<?php echo e($oatencion->pdf_oatencion); ?>">
                                        </div>
                                    </div> 
                                     
                                        <div>
                                            <br> 
                                            <input type="checkbox" id="checkFirma" name="checkFirma" onclick="Firma()"><b> Certifico la veracidad de la información aquí cargada y que esta ha sido registrada de manera completa. 
                                             </b> 
                                       </div>
                                   
                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <br>
                                        <button type="submit" class="btn btn-primary" id="btnFirma" disabled>Guardar</button>
                                        <input type="button" class="btn btn-secondary" value="Cancelar" onClick="history.go(-1);">
                                    </div>
                                </div>
                    </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/imac003/Desktop/GITHUB/MyControlSMA_git/resources/views/oatencion/editar.blade.php ENDPATH**/ ?>