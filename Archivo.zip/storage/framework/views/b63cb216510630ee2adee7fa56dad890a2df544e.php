<?php $__env->startSection('title'); ?>
    MyControlSMA-Facturacion
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Facturacion</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">


                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-facturacion')): ?>
                                <a class="btn btn-warning" href="<?php echo e(route('facturador.create')); ?>">Nuevo</a>
                            <?php endif; ?>
                            <div class="table-responsive"><br>
                                <table class="table table-striped mt-2" id="dataTable">
                                    <thead style="background-color:#575756">
                                        <th style="display: none;">ID</th>
                                        <th style="color:#fff;">Numero de orden</th>
                                        <th style="color:#fff;">Fec. Reg. Factura</th>
                                        <th style="color:#fff;">Fec. Factura</th>
                                        <th style="color:#fff;">Valor</th>
                                        <th style="color:#fff;">PDF</th>
                                        <th style="color:#fff;">Aprobada</th>
                                        <th style="color:#fff;">Observaciones</th>
                                        <th style="color:#fff;">Acciones</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $facturaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facturadors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td style="display: none;"><?php echo e($facturadors->id); ?></td>
                                                <td><?php echo e($facturadors->id_oservicio); ?></td>
                                                <td><?php echo e($facturadors->fec_reg_factura); ?></td>
                                                <td><?php echo e($facturadors->fec_factura); ?></td>
                                                <td><?php echo e($facturadors->valor_factura); ?></td>
                                                <td><a href="<?php echo e(asset('/storage/pdf_facturacion/'.$facturadors->pdf_facturacion)); ?>" target="_blank"><?php echo e($facturadors->pdf_facturacion); ?></a></td>
                                                <td><?php echo e($facturadors->aprobada_facturacion); ?></td>
                                                <td><?php echo e($facturadors->obs_facturacion); ?></td>
                                                <td>
                                                    <form action="<?php echo e(route('facturador.destroy', $facturadors->id)); ?>"
                                                        method="POST">
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar-facturacion')): ?>
                                                            <a class="btn btn-info"
                                                                href="<?php echo e(route('facturador.edit', $facturadors->id)); ?>">Editar</a>
                                                        <?php endif; ?>

                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('borrar-facturacion')): ?>
                                                            <button type="submit" class="btn btn-danger">Borrar</button>
                                                        <?php endif; ?>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- Ubicamos la paginacion a la derecha -->
                            <div class="pagination justify-content-end">
                                <?php echo $facturaciones->links(); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/imac003/Desktop/GITHUB/MyControlSMA_git/resources/views/facturador/index.blade.php ENDPATH**/ ?>