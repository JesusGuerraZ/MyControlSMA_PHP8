<?php $__env->startSection('title'); ?>
    MyControlSMA-Funcionarios
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Funcionarios</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">


                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-regional')): ?>
                                <a class="btn btn-warning" href="<?php echo e(route('funcionarios.create')); ?>">Nuevo</a>
                            <?php endif; ?>
                            <div class="table-responsive"><br>
                                <table class="table table-striped mt-2" id="dataTable">
                                    <thead style="background-color:#575756">
                                        <th style="display: none;">ID</th>
                                        <th style="color:#fff;">Cedula</th>
                                        <th style="color:#fff;">Funcionario</th>
                                        <th style="color:#fff;">Telefono</th>
                                        <th style="color:#fff;">Celular</th>
                                        <th style="color:#fff;">Regional</th>
                                        <th style="color:#fff;">acciones</th>

                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $funcionarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $funcionario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td style="display: none;"><?php echo e($funcionario->id); ?></td>
                                                <td><?php echo e($funcionario->ced_funcionario); ?></td>
                                                <td><?php echo e($funcionario->nom_ape_funcionario); ?></td>
                                                <td><?php echo e($funcionario->tel_funcionario); ?></td>
                                                <td><?php echo e($funcionario->cel_funcionario); ?></td>
                                                <td><?php echo e($funcionario->nom_regional); ?></td>
                                                <td>
                                                    <form action="<?php echo e(route('funcionarios.destroy', $funcionario->id)); ?>"
                                                        method="POST">
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar-funcionarios')): ?>
                                                            <a class="btn btn-info"
                                                                href="<?php echo e(route('funcionarios.edit', $funcionario->id)); ?>">Editar</a>
                                                        <?php endif; ?>

                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('borrar-funcionarios')): ?>
                                                            <button type="submit" class="btn btn-danger">Borrar</button>
                                                        <?php endif; ?>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/imac003/Desktop/MyControlSMA_PHP8/MyControlSMA_git/resources/views/funcionarios/index.blade.php ENDPATH**/ ?>